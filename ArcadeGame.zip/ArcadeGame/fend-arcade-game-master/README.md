

## What is this? 
FEND Projecdt!

![snippet](images/arcade.png)

## To play
[Arcade Game](https://arcade-game-fend.herokuapp.com/)

## Instructions
* Use your arrow keys to move the player: up, down, left, right. 
* Ensure your player doesn't collide with the bugs. You loose a life and 50pts on any collison.
